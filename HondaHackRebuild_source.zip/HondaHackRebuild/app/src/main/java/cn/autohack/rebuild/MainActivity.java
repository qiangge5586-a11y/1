package cn.autohack.rebuild;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    static final int BG=Color.rgb(16,21,29), PANEL=Color.rgb(27,35,46), PANEL2=Color.rgb(34,44,57);
    static final int TEXT=Color.rgb(239,244,249), MUTED=Color.rgb(145,160,176), ACCENT=Color.rgb(56,214,176), BLUE=Color.rgb(83,160,255);
    private LinearLayout root, content; private SharedPreferences prefs;
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);prefs=getSharedPreferences("vehicle",MODE_PRIVATE);showHome();}
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void showHome(){
        root=vertical();root.setBackgroundColor(BG);setContentView(root);
        LinearLayout top=horizontal();top.setPadding(dp(26),dp(16),dp(26),dp(12));
        ImageView logo=new ImageView(this);logo.setImageResource(getResources().getIdentifier("ic_launcher","drawable",getPackageName()));logo.setScaleType(ImageView.ScaleType.FIT_CENTER);top.addView(logo,new LinearLayout.LayoutParams(dp(42),dp(42)));
        LinearLayout brand=vertical();brand.setPadding(dp(12),0,0,0);brand.addView(text("HONDAHACK",18,TEXT,true));brand.addView(text("HONDA  /  ACURA  ·  VEHICLE CONTROL CENTER",9,MUTED,true));top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout status=horizontal();status.setBackground(shape(PANEL,22));status.setPadding(dp(14),dp(8),dp(14),dp(8));status.addView(dot(ACCENT));TextView st=text("本地模式 · 设备接口待连接",11,MUTED,false);st.setPadding(dp(8),0,0,0);status.addView(st);top.addView(status);root.addView(top);
        View line=new View(this);line.setBackgroundColor(Color.rgb(42,53,67));root.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        ScrollView scroll=new ScrollView(this);content=vertical();content.setPadding(dp(26),dp(20),dp(26),dp(24));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout welcome=horizontal();LinearLayout title=vertical();title.addView(text("车辆控制台",26,TEXT,true));title.addView(text("管理车机功能、快捷操作与车辆显示",12,MUTED,false));welcome.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout clock=vertical();clock.setGravity(Gravity.RIGHT);clock.addView(text(new SimpleDateFormat("EEE, dd MMM",Locale.CHINA).format(new Date()).toUpperCase(Locale.ROOT),11,MUTED,true));clock.addView(text(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()),22,TEXT,true));welcome.addView(clock);content.addView(welcome);
        LinearLayout stats=horizontal();stats.setPadding(0,dp(18),0,dp(18));stats.addView(stat("SYSTEM","就绪","基础功能可用"),new LinearLayout.LayoutParams(0,dp(76),1));stats.addView(stat("VEHICLE","未连接","等待车辆数据源"),new LinearLayout.LayoutParams(0,dp(76),1));stats.addView(stat("PROFILE",prefs.getString("profile","Honda"),"当前适配配置"),new LinearLayout.LayoutParams(0,dp(76),1));content.addView(stats);
        content.addView(text("功能模块",15,TEXT,true));content.addView(text("选择一个模块进入设置",10,MUTED,false));
        String[][] cards={
          {"方向盘按键","自定义按键动作与快捷启动","steering_wheel","keys"},
          {"仪表盘","车速、转速、水温、电压与油耗","speedometer","meter"},
          {"导航与音频","导航提示、音量策略与显示选项","gps_device","navigation"},
          {"开机视频","选择本地视频与启动提示","video","startup"},
          {"应用管理","查看已安装应用与快捷入口","rocket","apps"},
          {"系统与权限","设备状态、权限检查与诊断","settings","system"},
          {"语音助手","语音入口与助手偏好设置","voice_assistant_icon","voice"},
          {"关于与支持","版本信息、适配说明与日志","info","about"}
        };
        for(int i=0;i<cards.length;i+=4){LinearLayout row=horizontal();for(int j=i;j<Math.min(i+4,cards.length);j++){final String[] c=cards[j];row.addView(card(c),new LinearLayout.LayoutParams(0,dp(126),1));}content.addView(row);}
        TextView footer=text("HONDAHACK REBUILD  ·  安全模式  ·  不修改系统分区",9,MUTED,false);footer.setGravity(Gravity.CENTER);footer.setPadding(0,dp(18),0,0);content.addView(footer);
    }
    View dot(int color){View v=new View(this);v.setBackground(shape(color,20));v.setLayoutParams(new LinearLayout.LayoutParams(dp(7),dp(7)));return v;}
    View stat(String label,String value,String hint){LinearLayout box=vertical();box.setBackground(shape(PANEL,13));box.setPadding(dp(14),dp(10),dp(8),dp(8));TextView a=text(label,9,MUTED,true),b=text(value,16,TEXT,true),c=text(hint,9,MUTED,false);box.addView(a);box.addView(b);box.addView(c);LinearLayout.LayoutParams p=(LinearLayout.LayoutParams)box.getLayoutParams();return box;}
    View card(String[] c){LinearLayout box=vertical();box.setBackground(shape(PANEL,14));box.setPadding(dp(14),dp(12),dp(10),dp(10));box.setClickable(true);box.setFocusable(true);int id=getResources().getIdentifier(c[2],"drawable",getPackageName());if(id!=0){ImageView im=new ImageView(this);im.setImageResource(id);im.setColorFilter(ACCENT);box.addView(im,new LinearLayout.LayoutParams(dp(26),dp(26)));}TextView name=text(c[0],14,TEXT,true);name.setPadding(0,dp(9),0,dp(3));box.addView(name);TextView desc=text(c[1],10,MUTED,false);box.addView(desc);box.setOnClickListener(v->{Intent in=new Intent(this,ModuleActivity.class);in.putExtra("module",c[3]);in.putExtra("title",c[0]);startActivity(in);});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(126),1);lp.setMargins(dp(4),dp(7),dp(4),dp(7));box.setLayoutParams(lp);return box;}
}
