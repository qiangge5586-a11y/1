package cn.autohack.rebuild;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class ModuleActivity extends Activity {
    private LinearLayout body; private SharedPreferences prefs; private String module,title;
    private final int BG=MainActivity.BG,PANEL=MainActivity.PANEL,PANEL2=MainActivity.PANEL2,TEXT=MainActivity.TEXT,MUTED=MainActivity.MUTED,ACCENT=MainActivity.ACCENT;
    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);} 
    GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);prefs=getSharedPreferences("vehicle",MODE_PRIVATE);module=getIntent().getStringExtra("module");title=getIntent().getStringExtra("title");render();}
    void render(){LinearLayout root=col();root.setBackgroundColor(BG);setContentView(root);LinearLayout top=row();top.setPadding(dp(24),dp(18),dp(24),dp(16));TextView back=label("‹  返回",15,ACCENT,true);back.setOnClickListener(v->finish());top.addView(back);TextView heading=label(title,20,TEXT,true);heading.setPadding(dp(28),0,0,0);top.addView(heading);root.addView(top);View line=new View(this);line.setBackgroundColor(Color.rgb(45,56,70));root.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));ScrollView sc=new ScrollView(this);body=col();body.setPadding(dp(24),dp(20),dp(24),dp(28));sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
      switch(module){case "keys":keys();break;case "meter":meter();break;case "navigation":navigation();break;case "startup":startup();break;case "apps":apps();break;case "system":system();break;case "voice":voice();break;default:about();}
    }
    void section(String s){TextView t=label(s,14,TEXT,true);t.setPadding(0,dp(12),0,dp(8));body.addView(t);}
    void note(String s){TextView t=label(s,11,MUTED,false);t.setPadding(0,0,0,dp(10));body.addView(t);}
    void panel(View v){v.setBackground(shape(PANEL,13));v.setPadding(dp(15),dp(12),dp(15),dp(12));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(9);body.addView(v,p);}
    void action(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setTextColor(TEXT);b.setAllCaps(false);b.setBackground(shape(PANEL2,10));b.setOnClickListener(v->r.run());LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(48));p.bottomMargin=dp(8);body.addView(b,p);}
    void toggle(String key,String title,String subtitle,boolean def){LinearLayout box=col();TextView t=label(title,14,TEXT,true);TextView sub=label(subtitle,10,MUTED,false);box.addView(t);box.addView(sub);android.widget.Switch sw=new android.widget.Switch(this);sw.setButtonTintList(null);sw.setChecked(prefs.getBoolean(key,def));sw.setOnCheckedChangeListener((v,on)->prefs.edit().putBoolean(key,on).apply());box.addView(sw);panel(box);}
    void keys(){section("方向盘按键映射");note("保存的是本应用内的映射配置。实际接收车机方向盘按键，需要车辆厂商提供的广播、CAN 或系统输入接口。当前版本不会拦截系统按键。");String[] names={"音量 +","音量 −","上一曲","下一曲","语音 / Voice","MAP / 导航","自定义按键"};String[] values={"音量增加","音量减少","上一曲","下一曲","语音助手","打开导航","未设置"};for(int i=0;i<names.length;i++){final int n=i;LinearLayout box=col();box.addView(label(names[i],14,TEXT,true));TextView val=label(prefs.getString("key_"+i,values[i]),11,ACCENT,false);val.setPadding(0,dp(5),0,0);box.addView(val);box.setOnClickListener(v->{String[] choices={"音量增加","音量减少","上一曲","下一曲","播放 / 暂停","打开导航","打开语音助手","启动指定应用","不执行操作"};new android.app.AlertDialog.Builder(this).setTitle("设置："+names[n]).setItems(choices,(d,w)->{prefs.edit().putString("key_"+n,choices[w]).apply();val.setText(choices[w]);}).show();});panel(box);}action("保存按键配置",()->Toast.makeText(this,"配置已保存在本机",Toast.LENGTH_SHORT).show());}
    void meter(){section("仪表预览");note("演示数据，不代表真实车辆实时数据。连接经授权的车辆数据源后，才能显示真实车速、转速和温度。");LinearLayout grid=row();grid.addView(gauge("车速","0","km/h"),new LinearLayout.LayoutParams(0,dp(120),1));grid.addView(gauge("转速","0","rpm"),new LinearLayout.LayoutParams(0,dp(120),1));grid.addView(gauge("冷却液","--","°C"),new LinearLayout.LayoutParams(0,dp(120),1));body.addView(grid);LinearLayout grid2=row();grid2.addView(gauge("电压","--","V"),new LinearLayout.LayoutParams(0,dp(105),1));grid2.addView(gauge("平均油耗","--","L/100km"),new LinearLayout.LayoutParams(0,dp(105),1));body.addView(grid2);section("仪表选项");toggle("meter_enabled","启用仪表显示","打开仪表模块的显示配置",false);toggle("meter_nav","导航信息显示","在仪表区域预留导航信息",false);action("选择仪表样式",()->new android.app.AlertDialog.Builder(this).setTitle("仪表样式").setItems(new String[]{"简洁数字","运动风格","经典圆表"},(d,w)->prefs.edit().putInt("meter_style",w).apply()).show());}
    View gauge(String name,String value,String unit){LinearLayout b=col();b.setGravity(Gravity.CENTER);b.setBackground(shape(PANEL,13));b.addView(label(name,11,MUTED,true));TextView v=label(value,26,TEXT,true);v.setPadding(0,dp(8),0,dp(1));b.addView(v);b.addView(label(unit,10,ACCENT,false));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);p.setMargins(dp(4),dp(4),dp(4),dp(4));b.setLayoutParams(p);return b;}
    void navigation(){section("导航显示");toggle("nav_meter","导航信息上仪表","启用后仍需要兼容的车机数据接口",false);toggle("nav_voice","路线信息语音播报","预留导航播报开关",false);toggle("nav_dim","导航播报时降低音乐音量","音量调节仅在系统允许时生效",false);section("音量策略");TextView l=label("音乐压低幅度："+prefs.getInt("volume_duck",6),12,TEXT,false);body.addView(l);SeekBar bar=new SeekBar(this);bar.setMax(15);bar.setProgress(prefs.getInt("volume_duck",6));bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){l.setText("音乐压低幅度："+p);if(u)prefs.edit().putInt("volume_duck",p).apply();}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});body.addView(bar);}
    void startup(){section("开机体验");toggle("startup_sound","启动提示音","应用启动时显示提示，不修改系统启动流程",false);toggle("startup_video_enabled","启用开机视频配置","仅保存选择；系统级开机视频需要厂商授权接口",false);String selected=prefs.getString("startup_video","尚未选择视频");TextView file=label("当前文件："+selected,11,MUTED,false);panel(file);action("选择本地视频",()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("video/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,44);});}
    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(r==44&&c==RESULT_OK&&data!=null&&data.getData()!=null){Uri u=data.getData();getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);prefs.edit().putString("startup_video",u.toString()).apply();render();}}
    void apps(){section("应用快捷入口");note("系统安装的应用仍可从 Android 启动器打开。此处先提供常用导航与媒体应用的快捷配置，不扫描或上传已安装应用列表。");String[] pkgs={"com.autonavi.amapauto","com.google.android.apps.maps","cn.kuwo.kwmusiccar","com.spotify.music"};String[] names={"高德地图车机版","Google Maps","酷我音乐车机版","Spotify"};for(int i=0;i<pkgs.length;i++){final String pkg=pkgs[i];LinearLayout b=row();b.addView(label(names[i],14,TEXT,true),new LinearLayout.LayoutParams(0,-2,1));TextView open=label("打开  ›",12,ACCENT,true);b.addView(open);b.setOnClickListener(v->{Intent launch=getPackageManager().getLaunchIntentForPackage(pkg);if(launch!=null)startActivity(launch);else Toast.makeText(this,"未检测到该应用",Toast.LENGTH_SHORT).show();});panel(b);}}
    void system(){section("设备与权限检查");note("安全重建版不申请 Root，不替换 app_process，不覆盖 platform.xml，也不执行系统分区写入。");String[] names={"无障碍服务","修改系统设置","悬浮窗权限","应用通知"};for(String n:names){LinearLayout b=row();b.addView(label(n,13,TEXT,true),new LinearLayout.LayoutParams(0,-2,1));b.addView(label("按需授权",10,ACCENT,false));panel(b);}action("打开 Android 系统设置",()->startActivity(new Intent(Settings.ACTION_SETTINGS)));action("打开应用详情",()->startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()))));}
    void voice(){section("语音助手");toggle("voice_enabled","启用语音助手入口","保存助手启用状态；真实语音识别需配置语音服务",false);toggle("voice_beep","录音提示音","交互前提示用户语音采集状态",true);action("测试语音入口",()->new android.app.AlertDialog.Builder(this).setTitle("语音助手").setMessage("语音入口已就绪。当前构建未连接语音识别服务。\n\n接入时需明确麦克风权限与隐私提示。 ").setPositiveButton("知道了",null).show());}
    void about(){section("HondaHack Rebuild");note("基于用户提供的 7.6.0 APK 资源与逆向分析报告制作的独立重建工程。使用原包中的少量图标与仪表数据资源；未复制原 APK 的可执行代码、签名伪装、Root 安装器或远程吊销代码。");panel(label("版本：1.0.0-rebuild\n适配：Honda / Acura\n运行模式：本地安全模式\n包名：cn.autohack.rebuild",12,TEXT,false));action("查看应用信息",()->startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()))));}
}
