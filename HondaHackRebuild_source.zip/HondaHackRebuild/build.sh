#!/usr/bin/env bash
set -euo pipefail

if ! command -v java >/dev/null 2>&1; then
  echo '错误：未安装 JDK。请安装 JDK 17 或更高版本。' >&2
  exit 1
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo '错误：未安装 Gradle 8.7。请安装 Gradle 8.7，或使用 GitHub Actions 云端构建。' >&2
  exit 1
fi
if [[ -z "${ANDROID_HOME:-}${ANDROID_SDK_ROOT:-}" ]]; then
  echo '错误：未设置 ANDROID_HOME 或 ANDROID_SDK_ROOT。' >&2
  exit 1
fi
gradle --no-daemon --stacktrace assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
