@echo off
where java >nul 2>nul || (echo ERROR: Install JDK 17 or newer.& exit /b 1)
where gradle >nul 2>nul || (echo ERROR: Install Gradle 8.7 or use GitHub Actions cloud build.& exit /b 1)
if "%ANDROID_HOME%%ANDROID_SDK_ROOT%"=="" (echo ERROR: Set ANDROID_HOME or ANDROID_SDK_ROOT.& exit /b 1)
gradle --no-daemon --stacktrace assembleDebug
if errorlevel 1 exit /b %errorlevel%
echo APK: app\build\outputs\apk\debug\app-debug.apk
