# HondaHack Rebuild (Honda / Acura)

An independent Android rebuild scaffold based on the user-provided HondaHack 7.6.0 APK's visible feature inventory and selected visual resources.

## Current implementation
- Landscape automotive dashboard with Honda branding and a modern dark UI.
- Feature pages for steering-wheel mapping configuration, instrument preview, navigation/audio preferences, startup video selection, app shortcuts, system diagnostics, voice assistant preferences, and About.
- Local persistence via `SharedPreferences`.
- Original selected visual assets (icons) and meter JSON reference assets extracted from the supplied APK.
- No original DEX/native libraries, Xposed payload, certificate hook, root installer, system-partition scripts, license bypass, or remote-uninstall behavior are included.

## Build

### Cloud build (recommended when the local machine has no Android SDK)

This repository includes `.github/workflows/android-build.yml`. Upload/push this project to a GitHub repository, then open **Actions → Android APK build → Run workflow**. The workflow provisions JDK 17, Gradle 8.7, Android SDK Platform 35 and Build Tools 35.0.0, builds the debug APK, and publishes it as the downloadable artifact `HondaHackRebuild-debug-apk`.

### Android Studio

Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, install Android SDK Platform 35 and Build Tools 35.0.0, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

### Command line

Requirements: JDK 17+, Gradle 8.7, Android SDK Platform 35 and Build Tools 35.0.0. Set `ANDROID_HOME` or `ANDROID_SDK_ROOT`, then run `./build.sh` (Linux/macOS) or `build.bat` (Windows).

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

## Important functional boundaries
- The steering-wheel screen currently stores user-selected actions. Actual key interception requires a documented, authorized vehicle/OEM input API.
- Meter values are placeholders until a supported vehicle-data provider is connected.
- Startup video selection persists a local content URI. Replacing the system boot animation/video requires a vendor-supported API and is intentionally not implemented.
- Navigation/audio controls currently save preferences. Cross-app navigation events and audio ducking require supported integration points.
- System diagnostics open Android settings. This app does not request root and does not modify protected system files.

## Package
`cn.autohack.rebuild`

## Minimum / target SDK
Minimum 23; target 35; compile 35.
